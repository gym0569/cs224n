Word Vectors
--------------
![Alt text](https://github.com/akash9182/CS224n/blob/master/assignment1/q3_word_vectors.png?raw=true "Word vectors")

Errors that the model makes (with pretrained GloVe vectors)
--------------
![Alt text](https://github.com/akash9182/CS224n/blob/master/assignment1/q4_reg_v_acc.png?raw=true "Errors")

Some of the predictions and true labels:

| True Labels    | Prediction           | Sentence  |
| ------------- |:-------------:| -----:|
| 4      | 4 |         a warm , funny , engaging film |
|2        |2  | holy mad maniac in a mask , splat-man !|
|3        |3| good old-fashioned slash-and-hack is back !|
|4        |1| this flick is about as cool and crowd-pleasing as a documentary can get|
