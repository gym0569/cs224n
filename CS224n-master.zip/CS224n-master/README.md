# CS224n
A detailed explanation of topics and projects implemented is mentioned in respective assignment folder
